
//
// case.h
//
// Copyright (c) 2014 Stephen Mathieson
// MIT licensed
//


#ifndef CASE_H
#define CASE_H

char *
case_upper(char *);

char *
case_lower(char *);

char *
case_camel(char *);

#endif

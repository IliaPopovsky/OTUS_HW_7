
//
// rimraf.h
//
// Copyright (c) 2013 Stephen Mathieson
// MIT licensed
//

#ifndef RIMRAF_H
#define RIMRAF_H

#define RIMRAF_VERSION "0.0.1"

int
rimraf(const char *);

#endif
